#!/bin/sh

host=mqtt
port=1883
user="-u test"
password="-pw mqtt"
cseid="id-in"
csenm="cse-in"


poa="mqtt://test:mqtt@$host:$port/"
